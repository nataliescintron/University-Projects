package enums;
    public enum BookType{
        BOOK, EBOOK, PRINTED_BOOK
    }
/*
created this to make its own data Type
Since it is a string but not really, they're all
Kind of their own object
 */
