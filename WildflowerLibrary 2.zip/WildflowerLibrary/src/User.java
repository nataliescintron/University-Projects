import java.util.ArrayList;
import java.util.Date;

public class User {

    private String userID;
    private String name;
    private ArrayList<Loan> loans;

    public User(String userID, String name) {
        this.userID = userID;
        this.name = name;
        this.loans = new ArrayList<>();
    }

    // Simple checkout
    public void checkoutItem(LibraryItem item) {
        if (item == null) {
            System.out.println("Cannot check out a null item.");
            return;
        }

        if (!item.isAvailable()) {
            System.out.println("Item is already checked out: " + item.getTitle());
            return;
        }

        // Create a simple loan with today as loan date and due date in 14 days
        Loan loan = new Loan(
                "loan_" + System.currentTimeMillis(), // simple loanID
                item,
                this,
                new Date(),                           // loanDate
                new Date(System.currentTimeMillis() + 14L*24*60*60*1000) // dueDate 14 days later
        );

        loans.add(loan);
        item.checkOut();

        System.out.println(name + " checked out: " + item.getTitle());
    }

    // Simple return
    public void returnItem(LibraryItem item) {
        if (item == null) return;

        Loan foundLoan = null;
        for (Loan loan : loans) {
            if (loan.getLibraryItem().getId().equals(item.getId())) {
                foundLoan = loan;
                break;
            }
        }

        if (foundLoan == null) {
            System.out.println(name + " does not have this item checked out.");
            return;
        }

        loans.remove(foundLoan);
        item.returnItem();
        foundLoan.setReturnDate(new Date());

        System.out.println(name + " returned: " + item.getTitle());
    }

    // Optional getter for loans
    public ArrayList<Loan> getLoans() {
        return loans;
    }

    public String getName() {
        return name;
    }
    public String getUserID(){
        return userID;
    }
}
