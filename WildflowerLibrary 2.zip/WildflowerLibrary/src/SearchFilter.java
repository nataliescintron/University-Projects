import java.util.ArrayList;

public class SearchFilter {

    private String searchTerm;
    private String filterType; // e.g., title, author, genre, etc.
    private LibraryItem[] results; // Array to store search results

    public SearchFilter(String searchTerm, String filterType, LibraryItem[] results) {
        // initialize with provided values
        this.searchTerm = (searchTerm != null) ? searchTerm : "";
        this.filterType = (filterType != null) ? filterType : "";
        this.results = (results != null) ? results : new LibraryItem[0]; // safe fallback
    }

    public void setSearchTerm(String searchTerm) {
        // avoid null pointer issues
        if (searchTerm == null) {
            System.out.println("Search term cannot be null.");
            return;
        }
        this.searchTerm = searchTerm.trim();
    }

    public void setFilterType(String filterType) {
        if (filterType == null) {
            System.out.println("Filter type cannot be null.");
            return;
        }
        this.filterType = filterType.trim().toLowerCase();
    }

    public LibraryItem[] getSearchResult(LibraryItem[] items) {
        if (items == null || items.length == 0) {
            System.out.println("No library items available.");
            return new LibraryItem[0];
        }

        ArrayList<LibraryItem> resultsList = new ArrayList<>();

        for (LibraryItem item : items) {
            if (matchesSearchCriteria(item)) {
                resultsList.add(item);
            }
        }

        // Convert ArrayList to array and store results
        this.results = resultsList.toArray(new LibraryItem[0]);
        return this.results;
    }

    // helper method for matching search
    private boolean matchesSearchCriteria(LibraryItem item) {
        if (item == null || searchTerm.isEmpty() || filterType.isEmpty()) {
            return false;
        }

        String term = searchTerm.toLowerCase();

        switch (filterType) {
            case "title":
                return item.getTitle().toLowerCase().contains(term);

            case "author":
                return item.getAuthor().toLowerCase().contains(term);

            case "genre":
                // must check if item is a Book or subclass
                if (item instanceof Book) {
                    Book book = (Book) item;
                    return book.getGenre().toLowerCase().contains(term);
                }
                return false;

            default:
                System.out.println("Invalid filter type: " + filterType);
                return false;
        }
    }

    public String[] getAvailableFilterTypes() {
        return new String[]{"title", "author", "genre"};
    }

    public boolean isEmpty() {
        return results == null || results.length == 0;
    }
}


