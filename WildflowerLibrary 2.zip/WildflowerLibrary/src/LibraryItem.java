import enums.BookType;
abstract class LibraryItem{
    private String id;
    private String title;
    private String author;
    private String publicationDate;
    private BookType itemType;
    //attributes initialization
    public LibraryItem(String id, String title, String author,String publicationDate, BookType itemType){
        this.id = id;
        this.title = title;
        this.author = author;
        this.publicationDate = publicationDate;
        this.itemType = itemType;
    }
    //getter methods
    public String getId(){
        return this.id;//no need to reassign bc i want the same value to return
    }
    public String getTitle(){
        return this.title;
    }
    public String getAuthor(){
        return this.author;
    }
    public String getPublicationDate(){
        return this.publicationDate;
    }
    public BookType getItemType(){
        return this.itemType;
    }
    //LibraryItem Methods
    public abstract void checkOut();
    public abstract void returnItem();
    public abstract String getDetails();
    public abstract boolean isOverdue(String dueDate);
    public abstract void updateAvailability(Boolean status);
    public abstract boolean isAvailable();

}