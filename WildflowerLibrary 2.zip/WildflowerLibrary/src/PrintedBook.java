import enums.BookType;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

class PrintedBook extends Book {
    private String shelfLocation;

    //this whole thing is basically the same thing as Ebook but w/PrintedBook attributes/mods
    public PrintedBook(String id, String title, String author, String publicationDate,
                       BookType itemType, String genre, int numPages, String shelfLocation) {

        // call parent constructor (LibraryItem + Book attributes)
        super(id, title, author, publicationDate, itemType, genre, numPages);

        this.shelfLocation = shelfLocation; // Initialize PrintedBook attribute
    }

    @Override
    public String getDetails() {
        return super.getDetails() + "\nShelf Location: " + shelfLocation;
    }

    @Override
    public void checkOut() {
        // same logic as Book/EBook
        if (!super.isAvailable()) {
            System.out.println("PrintedBook is already checked out.");
            return;
        }
        super.updateAvailability(false);
        System.out.println("PrintedBook checked out: " + getTitle());
    }

    @Override
    public void returnItem() {
        // same logic as Book/EBook
        if (super.isAvailable()) {
            System.out.println("PrintedBook was not checked out.");
            return;
        }
        super.updateAvailability(true);
        System.out.println("PrintedBook returned: " + getTitle());
    }

    @Override
    public boolean isOverdue(String dueDate) {
        // same logic as Book/EBook
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate due = LocalDate.parse(dueDate, formatter);
            LocalDate today = LocalDate.now();

            return today.isAfter(due);

        } catch (DateTimeParseException e) {
            System.out.println("Invalid due date format. Use yyyy-MM-dd.");
            return false;
        }
    }

    @Override
    public void updateAvailability(Boolean status) {
        // same logic as Book/EBook
        if (status == null) {
            System.out.println("Invalid availability value.");
            return;
        }
        super.updateAvailability(status);
    }
}
