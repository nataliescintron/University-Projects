import enums.BookType;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
//need these three for the due date, todaysdate, and to calculate if someones late or not
class Book extends LibraryItem {
    private String genre;
    private int numPages;
    private boolean isAvailable = true; // i need this to track availability

    //child receives all parameters
    public Book(String id, String title, String author, String publicationDate, BookType itemType, String genre, int numPages) {
        //constructor of the parent class aka LibraryItem
        super(id, title, author, publicationDate, itemType);

        this.genre = genre;
        this.numPages = numPages;
    }


    public String getGenre() {
        return this.genre;
    }
    @Override
    public boolean isAvailable() {
        return this.isAvailable;
    }

    @Override
    public void checkOut() {
        if (!isAvailable) {
            System.out.println("Book is already checked out.");
            return;
        }
        isAvailable = false;
        System.out.println("Book checked out: " + getTitle());
    }

    @Override
    public void returnItem() {
        if (isAvailable) {
            System.out.println("Book was not checked out.");
            return;
        }
        isAvailable = true;
        System.out.println("Book returned: " + getTitle());
    }


    @Override
    public String getDetails() {
        return "Title: " + getTitle() + "\nAuthor: " + getAuthor() + "\nPublication Date: " + getPublicationDate() + "\nGenre: "
                + genre + " (" + numPages + " pages)" +
                ",\n Available: " + (isAvailable ? "Yes" : "No\n");
    }


    @Override
    public boolean isOverdue(String dueDate) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate due = LocalDate.parse(dueDate, formatter);
            LocalDate today = LocalDate.now();

            return today.isAfter(due);

        } catch (DateTimeParseException e) {
            System.out.println("Invalid due date format. Use yyyy-MM-dd.");
            return false; // fallback
        }
    }


    @Override
    public void updateAvailability(Boolean status) {
        if (status == null) {
            System.out.println("Invalid availability value.");
            return;
        }
        this.isAvailable = status;
    }
    //this one is for my subclasses

}

