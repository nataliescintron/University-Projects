import enums.BookType;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
class EBook extends Book {
    private double fileSize;
    private String format;

    public EBook(String id, String title, String author, String publicationDate, BookType itemType, String genre, int numPages, double fileSize, String format){
//superclass constructor all attributes from LibraryItem + Book
        super(id, title, author, publicationDate, itemType, genre, numPages);
        this.fileSize = fileSize; // Initialize EBook attributes
        this.format = format;
    }
    @Override
    public String getDetails() {
       //super.getDetails() calls Book getDetails with all that info ab author and other stuff
        return super.getDetails() +"\nFile Size: " + fileSize +"MB" + "\nFormat: " + format;
    }
    @Override
    public void checkOut() {
        // same logic as Book
        if (!super.isAvailable()) {
            System.out.println("EBook is already checked out.");
            return;
        }
            super.updateAvailability(false);
            System.out.println("EBook checked out: " + getTitle());

    }

    @Override
    public void returnItem() {
        // same logic as Book
        if (super.isAvailable()) {
            System.out.println("EBook was not checked out.");
            return;
        }
        super.updateAvailability(true);
        System.out.println("EBook returned: " + getTitle());
    }


    @Override
    public boolean isOverdue(String dueDate) {
        // same logic as Book
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate due = LocalDate.parse(dueDate, formatter);
            LocalDate today = LocalDate.now();

            return today.isAfter(due);

        } catch (DateTimeParseException e) {
            System.out.println("Invalid due date format. Use yyyy-MM-dd.");
            return false; // fallback
        }
    }

    @Override
    public void updateAvailability(Boolean status) {
        if (status == null) {
            System.out.println("Invalid availability value.");
            return;
        }
        super.updateAvailability(status);
    }


}


