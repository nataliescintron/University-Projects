import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;
//needed all these imports
public class Library {
//starting my class

    //These are the constant color ways for basically all the UI elements implemented in my methods
    private static Color BG_PINK = new Color(228, 173, 196);//Background color
    private static Color TEXT_DARK = new Color(50, 50, 50);// text color
    private static Color HEADER_PURPLE = new Color(102, 0, 102);// purple headers
    private static Color BUTTON_DARK = new Color(50, 50, 50);//button color
    private static Color BUTTON_TEXT_LIGHT = Color.BLACK;//Button text
    //this is the library wildlflower image logo. I made it default FINAL so it cant be changed
    private static final ImageIcon DEFAULT_ICON;

    static {
        ImageIcon tempIcon = null;//in case image isnt found
        java.net.URL url = Library.class.getResource("Library.jpg");//looks for the file, this is in the src folder
        if (url != null) {
            //loads image and scales it
            tempIcon = new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(125, 125, Image.SCALE_SMOOTH));
        }
        DEFAULT_ICON = tempIcon;//reassigned it to that variable
    }

    private ArrayList<User> users = new ArrayList<>();// stores all users in the library i add
    private ArrayList<LibraryItem> libraryItems = new ArrayList<>();//stores all books i add (printed/ebook)
    private User loggedInUser;//Keeps track of who's logged in currently

    public Library() {//constructor, runs when i do new Library() which is what i do at the main method at the bottom
        setupUsers();//this is basically running the data in the methods below
        setupLibraryItems();//this is basically running the data in the methods below
        showLoginScreen();//opens login screen for user
    }

    private void setupUsers() {
        //adding user data, this is calling a User object from our User class
        //it has  the id and name bc the constructor in User class is "public User(String userID, String name)"
        users.add(new User("U001", "Natalie"));
        users.add(new User("U002", "Carlos"));
        users.add(new User("U003", "Christopher"));
    }

    private void setupLibraryItems() {
        //adding book info, printed or electronic
        //depending if we make a new PrintedBook object or Ebook object from our classes, it will
        //adjust accoringly what the parameters will be
        libraryItems.add(new PrintedBook("Printed1001", "Little Women", "Louisa May Alcott", "1868",
                enums.BookType.PRINTED_BOOK, "Domestic Fiction", 759, "Shelf A4"));
        libraryItems.add(new EBook("Ebook1001", "Pride and Prejudice", "Jane Austen", "1813",
                enums.BookType.EBOOK, "Romance", 450, 2.5, "PDF"));
        libraryItems.add(new PrintedBook("Printed1002", "Pride and Prejudice", "Jane Austen", "1813",
                enums.BookType.PRINTED_BOOK, "Romance", 450, "Shelf A6"));
        libraryItems.add(new PrintedBook("Printed1003", "Screwtape Letters", "C.S Lewis", "1942",
                enums.BookType.PRINTED_BOOK, "Satire", 160, "Shelf A3"));
        libraryItems.add(new EBook("Ebook1003", "Screwtape Letters", "C.S Lewis", "1942",
                enums.BookType.EBOOK, "Satire", 160, 1.2, "PDF"));
    }

    //the login screen
    private void showLoginScreen() {
        //creating the main frame(window) which is named library login
        JFrame frame = new JFrame("Library Login");
        frame.setSize(600, 300);//size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes when user exits
        frame.setLocationRelativeTo(null);//centers window
        frame.getContentPane().setBackground(BG_PINK);//background color using constant variable

        //panel to organize labels, text fields and buttons
        JPanel loginPanel = new JPanel();//creating new panel object
        loginPanel.setBackground(BG_PINK);//color
        loginPanel.setLayout(new BoxLayout(loginPanel, BoxLayout.Y_AXIS));// makes it top to bottom
        loginPanel.setBorder(BorderFactory.createEmptyBorder(30, 60, 30, 60));//padding so it looks nicer

        JLabel mainHeaderLabel = new JLabel("Welcome to the Wildflower Library");//header label on the top
        mainHeaderLabel.setFont(new Font("SansSerif", Font.BOLD, 18));//font
        mainHeaderLabel.setForeground(HEADER_PURPLE);//color using constant variable
        mainHeaderLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        loginPanel.add(mainHeaderLabel);
        loginPanel.add(Box.createVerticalStrut(20));

        JLabel idLabel = new JLabel("User ID:");//label for user id
        JLabel nameLabel = new JLabel("Name:");//label for name
        JTextField idField = new JTextField();//creating text field for user id
        JTextField nameField = new JTextField();//creating text field for name
        JButton loginButton = new JButton("Login");//creating login button
//max size for the text fields so its not really big
        Dimension fieldSize = new Dimension(180, 25);
        idField.setMaximumSize(fieldSize);
        nameField.setMaximumSize(fieldSize);

        //centering all the components we just made above ^
        idLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        idField.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        nameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        //login button aesthetics
        loginButton.setBackground(Color.WHITE);
        loginButton.setForeground(TEXT_DARK);
        loginButton.setFocusPainted(false);
        loginButton.setPreferredSize(new Dimension(100, 30));
//now this is adding all the labels and fields we made after constructing them
        loginPanel.add(idLabel);
        loginPanel.add(Box.createVerticalStrut(5));//these all add spaces in between
        loginPanel.add(idField);
        loginPanel.add(Box.createVerticalStrut(15));
        loginPanel.add(nameLabel);
        loginPanel.add(Box.createVerticalStrut(5));
        loginPanel.add(nameField);
        loginPanel.add(Box.createVerticalStrut(20));
        loginPanel.add(loginButton);

        frame.add(loginPanel, BorderLayout.CENTER);//centers it
        //kinda adding functionality
        loginButton.addActionListener(e -> {
            String id = idField.getText().trim();//trim() removes extra space
            String name = nameField.getText().trim();//these retreive the names typed in the text fields by the user
            boolean loggedIn = false;//
            for (User user : users) {//loops through users
                //basically if a match is found with both the ID and the user name, then
                if (user.getUserID().equals(id) && user.getName().equalsIgnoreCase(name)) {
                    loggedInUser = user;//this will initialize the user info as the logged in user
                    frame.dispose();//closed login window
                    showDashboard();//opens the dashboard
                    loggedIn = true;
                    break;//break so it doesnt do the if block below
                }
            }
            //if block jsut incase the information doesnt match to anything
            if (!loggedIn) {
                JPanel panel = new JPanel();
                panel.setBackground(BG_PINK);
                panel.add(new JLabel("Invalid user ID or name."));//shows login error
                JOptionPane.showMessageDialog(null, panel, "Login Error", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON);//also default icon is the library.jpg
            }
        });

        frame.setVisible(true);//displaying all of this aka the login window
    }

    private void showDashboard() {//dashboard display after login
        //this is creating the main window for the dashboard
        JFrame dashboardFrame = new JFrame("Library Dashboard");//name
        dashboardFrame.setSize(400, 300);//size
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes if user exits
        dashboardFrame.setLocationRelativeTo(null);//centers window
        dashboardFrame.getContentPane().setBackground(BG_PINK);//background color
        dashboardFrame.setLayout(new BorderLayout());//will let me organize components
//adding a welcome header label
        JLabel welcomeLabel = new JLabel("Welcome, " + loggedInUser.getName(), SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 16));//font
        welcomeLabel.setForeground(HEADER_PURPLE);//font color
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));//adding padding
        dashboardFrame.add(welcomeLabel, BorderLayout.NORTH);//north aka top of the fram
//this is a panel for the buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BG_PINK);
        buttonPanel.setLayout(new GridLayout(4, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
//now we are actually creating the buttons below
        String[] options = {"List All Items", "Search Items", "My Loans", "Logout"};
        for (String optionText : options) {//looping through the array
            JButton button = new JButton(optionText);//creating a JButton for each one with the details below
            button.setBackground(BUTTON_DARK);
            button.setForeground(BUTTON_TEXT_LIGHT);
            button.setFocusPainted(false);
//Adding an action when each button is clicked
            button.addActionListener(e -> {
                switch (e.getActionCommand()) {
                    case "List All Items" -> listAllItems();//e.g if this is clicked, call the listAllItems() method
                    case "Search Items" -> searchItems();
                    case "My Loans" -> showLoans();
                    case "Logout" -> {
                        dashboardFrame.dispose();
                        loggedInUser = null;
                        showLoginScreen();
                    }
                }
            });
            buttonPanel.add(button);//now this is adding the button to the panel after each iteration
        }
        dashboardFrame.add(buttonPanel, BorderLayout.CENTER);
        dashboardFrame.setVisible(true);
    }

    //these methods below are basically the button method functionalities
    //creating main panel for all the books
    private void listAllItems() {
        JPanel allBooksPanel = new JPanel(); // holds all book entries
        allBooksPanel.setLayout(new BoxLayout(allBooksPanel, BoxLayout.Y_AXIS)); // stacks everything top to bottom
        allBooksPanel.setBackground(BG_PINK);

        for (LibraryItem item : libraryItems) {//loops through all library items
            JPanel bookPanel = new JPanel(new BorderLayout());
            bookPanel.setBackground(BG_PINK);

            //text area for all the book details
            JTextArea area = new JTextArea(item.getDetails());//Calling getDetails from libraryItem class
            //displays all info
            area.setEditable(false);//NOT editable
            area.setBackground(BG_PINK);
            area.setForeground(TEXT_DARK);

            // Book image - all images are in src folder
            String imagePath = switch (item.getTitle().toLowerCase()) {
                case "screwtape letters" -> "screwtape.jpg";//if title == this, then use this image
                case "little women" -> "LittleWomen.jpeg";
                case "pride and prejudice" -> "PrideAndPrejudice.jpg";
                default -> null;//nothing if no image
            };

            if (imagePath != null) {//if there is a image
                java.net.URL url = getClass().getResource(imagePath);//get the image from location
                if (url != null) {
                    bookPanel.add(new JLabel(new ImageIcon(new ImageIcon(url)
                            .getImage().getScaledInstance(100, 175, Image.SCALE_SMOOTH))), BorderLayout.WEST);
                    //then this loads it, scaled is and adds it to the left on the textarea panel
                }
            }

            bookPanel.add(area, BorderLayout.CENTER);
            allBooksPanel.add(bookPanel);
            allBooksPanel.add(Box.createVerticalStrut(10)); // spacing
        }
//scroll panel to scroll throughout
        JScrollPane scrollPane = new JScrollPane(allBooksPanel);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(null, scrollPane, "All Items List", JOptionPane.PLAIN_MESSAGE);
    }

    private void searchItems() {
        //creating an input field for the search item
        JTextField termField = new JTextField(12);
        JPanel p = new JPanel();
        p.setBackground(BG_PINK);
        p.add(new JLabel("Search Term:"));
        p.add(termField);//adding the text field
//showing the dialog to get the search term
        int result = JOptionPane.showConfirmDialog(null, p, "Search", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON);
        if (result != JOptionPane.OK_OPTION) return;//exit if wanted

        String term = termField.getText().trim();//getting the text typed in
        if (term.isEmpty()) return;//exit if empty

        String[] filters = {"title", "author", "genre"};//our filter type options
        JPanel filterPanel = new JPanel();//jpanel for label
        filterPanel.setBackground(BG_PINK);
        filterPanel.add(new JLabel("Select filter:"));//making a label names this
// show dialog to select the filter.
        String filter = (String) JOptionPane.showInputDialog(null, filterPanel, "Filter Options", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON, filters, filters);
        if (filter == null) return;
//new search filter object with the term, filter  and converts my arraylist to a libraryitem[] for a search
        SearchFilter sf = new SearchFilter(term, filter, libraryItems.toArray(new LibraryItem[0]));
        LibraryItem[] results = sf.getSearchResult(libraryItems.toArray(new LibraryItem[0]));
//performing the search
        //checks to see if there were no results returned aka not a match
        if (results == null || results.length == 0) {
            JPanel messagePanel = new JPanel();
            messagePanel.setBackground(BG_PINK);
            messagePanel.add(new JLabel("No matching items found for \"" + term + "\"."));
            //no matching message
            JOptionPane.showMessageDialog(null, messagePanel, "Search Results", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON);
            return;
        }
//show a dialog so the user can pick one item from the search results
        LibraryItem selectedItem = selectLibraryItem(results);
        if (selectedItem != null) showBookDetails(selectedItem);
    }

    private void showLoans() {
        //check if no loans are there first
        if (loggedInUser.getLoans().isEmpty()) {
            //make a jPanel to put a message in
            JPanel panel = new JPanel();
            panel.setBackground(BG_PINK);
            panel.add(new JLabel("You have no current loans."));
            JOptionPane.showMessageDialog(null, panel, "My Loans", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON);
            return;
        }
//concert the arraylist<loan> to a loan[] array
        Loan[] loanArray = loggedInUser.getLoans().toArray(new Loan[0]);
        //method that allows usr to select one loan from current loans
        Loan selectedLoan = selectLoan(loanArray);
        if (selectedLoan != null) showLoanDetails(selectedLoan);//shows loan details of selected loan
    }

    private LibraryItem selectLibraryItem(LibraryItem[] items) {

        String[] options = new String[items.length];
        //loops through al the libraryItem items aka books regardless what types
        for (int i = 0; i < items.length; i++) options[i] = items[i].getTitle() + " (" + items[i].getId() + ")";
        JPanel panel = new JPanel();
        panel.setBackground(BG_PINK);
        panel.add(new JLabel("Select a book:"));//allow to select a book
//reutns a string showing what the user selected
        String choice = (String) JOptionPane.showInputDialog(null, panel, "Books", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON, options, options);
        if (choice == null) return null;//if user canceled the dialog
//matches choice w the books ID and returns the corresponding library item
        for (LibraryItem item : items) if (choice.contains(item.getId())) return item;
        return null;//if no match is found
    }
//same as selectLibraryItem but for loan!
    private Loan selectLoan(Loan[] loans) {
        String[] options = new String[loans.length];
        for (int i = 0; i < loans.length; i++)
            options[i] = loans[i].getLibraryItem().getTitle() + " (" + loans[i].getLibraryItem().getId() + ")";

        JPanel panel = new JPanel();
        panel.setBackground(BG_PINK);
        panel.add(new JLabel("Select a loan:"));

        String choice = (String) JOptionPane.showInputDialog(null, panel, "Loans", JOptionPane.PLAIN_MESSAGE, DEFAULT_ICON, options, options);
        if (choice == null) return null;

        for (Loan loan : loans) if (choice.contains(loan.getLibraryItem().getId())) return loan;
        return null;
    }
//this displays the details of library items and lets them checkout
    private void showBookDetails(LibraryItem item) {
        // takes one image as a parameter
        String imagePath = null;//placeholder
        //this is to figure out which image to show based on books title and assigns it to imagePath variable
        if (item.getTitle().equalsIgnoreCase("Screwtape Letters")) imagePath = "screwtape.jpg";
        else if (item.getTitle().equalsIgnoreCase("Little Women")) imagePath = "LittleWomen.jpeg";
        else if (item.getTitle().equalsIgnoreCase("Pride and Prejudice")) imagePath = "PrideAndPrejudice.jpg";

        ImageIcon icon = null;//placeholder
        if (imagePath != null) {
            java.net.URL iconURL = getClass().getResource(imagePath);//loads the corresponding image and scales it
            if (iconURL != null) icon = new ImageIcon(new ImageIcon(iconURL).getImage().getScaledInstance(150, 200, Image.SCALE_SMOOTH));
        }
//creating a text area to display the text information
        JTextArea area = new JTextArea(item.getDetails());
        area.setEditable(false);
        area.setBackground(BG_PINK);
        area.setForeground(TEXT_DARK);
//need this to combine text and image
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_PINK);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);//scrollpanel just incase too long
        if (icon != null) panel.add(new JLabel(icon), BorderLayout.WEST);
//showing book info, asking if user wants to check out and then two buttons allowing that
        int option = JOptionPane.showConfirmDialog(null, panel, "Book Details - Checkout?", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.YES_OPTION) {
            loggedInUser.checkoutItem(item);
//if yes then allow item to be checked out
            //message after it was checked out
            JPanel confirmPanel = new JPanel(new BorderLayout());
            confirmPanel.setBackground(BG_PINK);
            confirmPanel.add(new JLabel("Book \"" + item.getTitle() + "\" was checked out!"), BorderLayout.NORTH);
            if (icon != null) confirmPanel.add(new JLabel(icon), BorderLayout.WEST);
//adding the image there too
            JOptionPane.showMessageDialog(null, confirmPanel, "Checkout Complete", JOptionPane.PLAIN_MESSAGE);
        }
    }
//takes one loan in as a parameter and this is to view that loan details
    private void showLoanDetails(Loan loan) {
        // null variables that wil be assigned later on
        ImageIcon icon = null;
        String path = null;
        String title = loan.getLibraryItem().getTitle();//gets the title and then uses it to get the book Icon
        if (title.equalsIgnoreCase("Screwtape Letters")) icon = getBookIcon("screwtape.jpg");
        else if (title.equalsIgnoreCase("Little Women")) icon = getBookIcon("LittleWomen.jpeg");
        else if (title.equalsIgnoreCase("Pride and Prejudice")) icon = getBookIcon("PrideAndPrejudice.jpg");
//creating the text area for loan details with aesthetics
        JTextArea area = new JTextArea(loan.getLibraryItem().getDetails() + "\nLoan Date: " + loan.getLoanDate() + "\nDue Date: " + loan.getDueDate());
        area.setEditable(false);
        area.setBackground(BG_PINK);
        area.setForeground(TEXT_DARK);
//combining the text and image panel
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(BG_PINK);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        if (icon != null) panel.add(new JLabel(icon), BorderLayout.WEST);
//confirm dialog that will ask if you want to return the book or not
        int option = JOptionPane.showConfirmDialog(null, panel, "Loan Details - Return Book?", JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.YES_OPTION) {//of yes then mark as returned
            loggedInUser.returnItem(loan.getLibraryItem());
            loan.markAsReturned(new Date());
//returned book panel
            JPanel returnPanel = new JPanel(new BorderLayout());
            returnPanel.setBackground(BG_PINK);
            returnPanel.add(new JLabel("Book returned! Return Date: " + loan.getReturnDate()), BorderLayout.NORTH);
            if (icon != null) returnPanel.add(new JLabel(icon), BorderLayout.WEST);

            JOptionPane.showMessageDialog(null, returnPanel, "Return Confirmation", JOptionPane.PLAIN_MESSAGE);
        }
    }
//helper method to get the images from the resources so this is used in other methods to get the photots for the books and sets their aesthetics
    private ImageIcon getBookIcon(String path) {
        java.net.URL url = getClass().getResource(path);
        if (url != null) return new ImageIcon(new ImageIcon(url).getImage().getScaledInstance(150, 200, Image.SCALE_SMOOTH));
        return null;
    }
//creates new instance of library class and this is run!
    public static void main(String[] args) {
        new Library();
    }
}

