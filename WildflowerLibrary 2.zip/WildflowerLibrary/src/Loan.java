import java.util.Date;

public class Loan {
    private String loanID;
    private LibraryItem libraryItem;
    private User user;
    private Date loanDate;
    private Date dueDate;
    private Date returnDate;

    // Constructor
    public Loan(String loanID, LibraryItem libraryItem, User user, Date loanDate, Date dueDate) {
        this.loanID = loanID;
        this.libraryItem = libraryItem;
        this.user = user;
        this.loanDate = loanDate;
        this.dueDate = dueDate;
        this.returnDate = null; //for now
    }

    // Getters
    public String getLoanID() {
        return loanID;
    }

    public LibraryItem getLibraryItem() {
        return libraryItem;
    }

    public User getUser() {
        return user;
    }

    public Date getLoanDate() {
        return loanDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    // Setters
    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }


    public boolean isOverdue() {
        if (returnDate != null) return false; // already returned
        Date today = new Date();
        return today.after(dueDate);
    }


    public void markAsReturned(Date returnDate) {
        setReturnDate(returnDate);
        if (libraryItem != null) {
            libraryItem.updateAvailability(true);
        }
    }
}
